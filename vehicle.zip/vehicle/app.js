// index.js

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// In-memory database
let vehicles = [];

// Vehicle model
class Vehicle {
    constructor(vehicleName, price, image, desc, brand) {
        this.vehicleName = vehicleName;
        this.price = price;
        this.image = image;
        this.desc = desc;
        this.brand = brand;
    }
}

// CRUD operations

// Create a Vehicle
app.post('/vehicles', (req, res) => {
    const { vehicleName, price, image, desc, brand } = req.body;
    const newVehicle = new Vehicle(vehicleName, price, image, desc, brand);
    vehicles.push(newVehicle);
    res.status(201).json(newVehicle);
});

// Read all Vehicles
app.get('/vehicles', (req, res) => {
    res.status(200).json(vehicles);
});

// Read a specific Vehicle
app.get('/vehicles/:index', (req, res) => {
    const { index } = req.params;
    if (vehicles[index]) {
        res.status(200).json(vehicles[index]);
    } else {
        res.status(404).send('Vehicle not found');
    }
});

// Update a Vehicle
app.put('/vehicles/:index', (req, res) => {
    const { index } = req.params;
    if (vehicles[index]) {
        const { vehicleName, price, image, desc, brand } = req.body;
        vehicles[index] = new Vehicle(vehicleName, price, image, desc, brand);
        res.status(200).json(vehicles[index]);
    } else {
        res.status(404).send('Vehicle not found');
    }
});

// Delete a Vehicle
app.delete('/vehicles/:index', (req, res) => {
    const { index } = req.params;
    if (vehicles[index]) {
        vehicles.splice(index, 1);
        res.status(204).send();
    } else {
        res.status(404).send('Vehicle not found');
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
